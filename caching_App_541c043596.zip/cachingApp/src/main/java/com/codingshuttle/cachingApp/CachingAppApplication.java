package com.codingshuttle.cachingApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CachingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CachingAppApplication.class, args);
	}

}
